place seed database in this directory.
